# EcoCorp: Antalya 2026 — Varlık kredileri

## Kullanılan varlıklar

Bu revizyonda internetten indirilen raster/bitmap veya ses dosyası kullanılmamıştır. Menü arka planı, ofis sahnesi, UI yüzeyleri ve eko taşları Godot 4 GDScript ile aynı renk paletinde çizilen özgün vektör-benzeri şekillerdir. Bu nedenle üçüncü taraf sanatçı kredisi veya ek lisans yükümlülüğü yoktur.

## Lisans araştırması

- Kenney — UI Pack, CC0: https://kenney.nl/assets/ui-pack
  - Kaynak ve lisans doğrulandı; ancak bu prototipin görsel diliyle tutarlı bir dış UI paketi kullanmak yerine tüm UI yüzeyleri özel çizildi.

- Yazı tipi: Godot fallback fontu / sistem yazı tipi. Harici font paketi yoktur.
