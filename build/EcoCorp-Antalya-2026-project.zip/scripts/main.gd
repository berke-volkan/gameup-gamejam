extends Control

const BG := Color("#08261f")
const BG_2 := Color("#123c30")
const CREAM := Color("#f2ead8")
const INK := Color("#173d31")
const MUTED := Color("#9bb9a3")
const SAGE := Color("#a9d7a1")
const YELLOW := Color("#f2c94c")
const PANEL := Color("#14392f")
const PANEL_2 := Color("#1c493b")

var page := "office"
var stage: HBoxContainer
var title_label: Label
var cc_label: Label
var toast: Label
var board: Control
var office: Control
var goal_progress: ProgressBar
var goal_label: Label

func _ready() -> void:
    GameState.load_progress()
    GameState.state_changed.connect(_refresh)
    GameState.toast_requested.connect(_show_toast)
    _show_menu()

func _show_menu() -> void:
    for child in get_children(): child.queue_free()
    var backdrop := preload("res://scripts/menu_backdrop.gd").new()
    backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(backdrop)
    var overlay := ColorRect.new(); overlay.color = Color(0.02, 0.12, 0.09, 0.38); overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(overlay)
    var margin := MarginContainer.new(); margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); margin.add_theme_constant_override("margin_left", 76); margin.add_theme_constant_override("margin_right", 76); margin.add_theme_constant_override("margin_top", 54); margin.add_theme_constant_override("margin_bottom", 54); add_child(margin)
    var columns := HBoxContainer.new(); columns.add_theme_constant_override("separation", 44); margin.add_child(columns)
    var copy := VBoxContainer.new(); copy.size_flags_horizontal = Control.SIZE_EXPAND_FILL; copy.alignment = BoxContainer.ALIGNMENT_CENTER; copy.add_theme_constant_override("separation", 12); columns.add_child(copy)
    var kicker := Label.new(); kicker.text = "ANTALYA / 2026"; kicker.add_theme_font_size_override("font_size", 18); kicker.add_theme_color_override("font_color", YELLOW); copy.add_child(kicker)
    var logo := Label.new(); logo.text = "ECOCORP"; logo.add_theme_font_size_override("font_size", 76); logo.add_theme_color_override("font_color", CREAM); copy.add_child(logo)
    var subtitle := Label.new(); subtitle.text = "Şehrin enerjisini dönüştür."; subtitle.add_theme_font_size_override("font_size", 28); subtitle.add_theme_color_override("font_color", SAGE); copy.add_child(subtitle)
    var blurb := Label.new(); blurb.text = "Sürdürülebilir teknoloji şirketini kur, ekibini büyüt\nve Antalya'nın iklim geleceğine yatırım yap."; blurb.add_theme_font_size_override("font_size", 18); blurb.add_theme_color_override("font_color", CREAM); blurb.modulate = Color(1,1,1,.82); copy.add_child(blurb)
    var spacer := Control.new(); spacer.custom_minimum_size.y = 16; copy.add_child(spacer)
    var start := _button("OYUNA BAŞLA  →", YELLOW, INK); start.custom_minimum_size = Vector2(280, 64); start.pressed.connect(_start_game); copy.add_child(start)
    var how := _button("Nasıl oynanır?", Color(0,0,0,0), CREAM); how.custom_minimum_size = Vector2(220, 48); how.pressed.connect(_show_how_to_play); copy.add_child(how)
    var art_panel := PanelContainer.new(); art_panel.custom_minimum_size = Vector2(540, 500); art_panel.add_theme_stylebox_override("panel", _style(Color(0.06, .2, .15, .72), 28)); columns.add_child(art_panel)
    var art := preload("res://scripts/office_view.gd").new(); art.show_menu_scene = true; art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); art_panel.add_child(art)
    var footer := Label.new(); footer.text = "Bir sunum prototipi • kayıt otomatik tutulur"; footer.position = Vector2(78, 674); footer.add_theme_font_size_override("font_size", 13); footer.add_theme_color_override("font_color", Color(1,1,1,.55)); add_child(footer)

func _show_how_to_play() -> void:
    var layer := ColorRect.new(); layer.color = Color(0.02, .09, .07, .72); layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); layer.mouse_filter = Control.MOUSE_FILTER_STOP; add_child(layer)
    var panel := PanelContainer.new(); panel.custom_minimum_size = Vector2(620, 330); panel.set_anchors_preset(Control.PRESET_CENTER); panel.position = Vector2(330, 180); panel.add_theme_stylebox_override("panel", _style(CREAM, 24)); layer.add_child(panel)
    var box := VBoxContainer.new(); box.add_theme_constant_override("separation", 14); panel.add_child(box)
    var title := Label.new(); title.text = "EcoCorp nasıl oynanır?"; title.add_theme_font_size_override("font_size", 28); title.add_theme_color_override("font_color", INK); box.add_child(title)
    var body := Label.new(); body.text = "1  Günün Oyunu'nda komşu taşları değiştir.\n2  Eko zincirlerinden CC kazan.\n3  CC ile ofisi yükselt ve yeni uzmanlar işe al.\n4  Pasif gelirle Antalya'daki dönüşümü hızlandır."; body.add_theme_font_size_override("font_size", 18); body.add_theme_color_override("font_color", Color("#466153")); body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; box.add_child(body)
    var close := _button("ANLADIM", INK, CREAM); close.custom_minimum_size.y = 50; close.pressed.connect(func(): layer.queue_free()); box.add_child(close)

func _start_game() -> void:
    _build_shell()
    _show_office()

func _build_shell() -> void:
    for child in get_children(): child.queue_free()
    var bg := ColorRect.new(); bg.color = BG; bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(bg)
    var root := VBoxContainer.new(); root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); root.offset_left = 34; root.offset_right = -34; root.offset_top = 24; root.offset_bottom = -24; root.add_theme_constant_override("separation", 14); add_child(root)
    var top := HBoxContainer.new(); top.custom_minimum_size.y = 52; root.add_child(top)
    var brand := Label.new(); brand.text = "ECOCORP  /  ANTALYA 2026"; brand.add_theme_font_size_override("font_size", 22); brand.add_theme_color_override("font_color", CREAM); top.add_child(brand)
    var top_spacer := Control.new(); top_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL; top.add_child(top_spacer)
    cc_label = Label.new(); cc_label.add_theme_font_size_override("font_size", 22); cc_label.add_theme_color_override("font_color", YELLOW); top.add_child(cc_label)
    var home := _button("ANA MENÜ", Color(0,0,0,0), MUTED); home.custom_minimum_size = Vector2(120, 42); home.pressed.connect(_show_menu); top.add_child(home)
    var divider := HSeparator.new(); divider.modulate = Color(1,1,1,.12); root.add_child(divider)
    title_label = Label.new(); title_label.add_theme_font_size_override("font_size", 32); title_label.add_theme_color_override("font_color", CREAM); root.add_child(title_label)
    stage = HBoxContainer.new(); stage.size_flags_vertical = Control.SIZE_EXPAND_FILL; stage.add_theme_constant_override("separation", 18); root.add_child(stage)
    var nav := HBoxContainer.new(); nav.custom_minimum_size.y = 54; nav.add_theme_constant_override("separation", 10); root.add_child(nav)
    for item in [["OFİS", "office"], ["İŞE ALIM", "recruitment"], ["GÜNÜN OYUNU", "game"]]:
        var b := _button(item[0], PANEL_2, CREAM); b.name = "nav_" + item[1]; b.size_flags_horizontal = Control.SIZE_EXPAND_FILL; b.pressed.connect(func(): _navigate(item[1])); nav.add_child(b)
    toast = Label.new(); toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; toast.custom_minimum_size.y = 22; toast.add_theme_color_override("font_color", YELLOW); root.add_child(toast)
    _refresh()

func _navigate(target: String) -> void:
    page = target
    if page == "office": _show_office()
    elif page == "recruitment": _show_recruitment()
    else: _show_game()

func _reset_stage() -> void:
    for child in stage.get_children(): child.queue_free()

func _show_office() -> void:
    _reset_stage(); title_label.text = "Şirket merkezi"
    var office_panel := _panel(); office_panel.name = "office_panel"; office_panel.custom_minimum_size.x = 520; office_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL; office_panel.size_flags_stretch_ratio = 1.35; stage.add_child(office_panel)
    var office_box := VBoxContainer.new(); office_box.add_theme_constant_override("separation", 8); office_panel.add_child(office_box)
    var office_header := _section_label("OFİS GÖRÜNÜMÜ", MUTED); office_box.add_child(office_header)
    office = preload("res://scripts/office_view.gd").new(); office.custom_minimum_size.y = 250; office.size_flags_vertical = Control.SIZE_EXPAND_FILL; office_box.add_child(office)
    var office_note := Label.new(); office_note.text = "Her yatırım, Antalya'daki merkezimizi görünür biçimde dönüştürür."; office_note.add_theme_font_size_override("font_size", 15); office_note.add_theme_color_override("font_color", MUTED); office_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; office_box.add_child(office_note)
    var upgrade_title := _section_label("İKLİM ALTYAPISI  /  CC İLE KUR", YELLOW); office_box.add_child(upgrade_title)
    var upgrade_flow := HFlowContainer.new(); upgrade_flow.name = "upgrade_flow"; upgrade_flow.add_theme_constant_override("h_separation", 8); upgrade_flow.add_theme_constant_override("v_separation", 6); office_box.add_child(upgrade_flow)
    for id in GameState.UPGRADES.keys():
        var item: Dictionary = GameState.UPGRADES[id]
        var upgrade_button := _button("%s\n%d CC" % [item.name, item.cost], SAGE if not GameState.upgrades.get(id, false) else PANEL_2, INK if not GameState.upgrades.get(id, false) else CREAM)
        upgrade_button.name = "upgrade_" + id; upgrade_button.custom_minimum_size = Vector2(145, 46); upgrade_button.add_theme_font_size_override("font_size", 12); upgrade_button.pressed.connect(func(): GameState.buy_upgrade(id)); upgrade_flow.add_child(upgrade_button)
        if GameState.upgrades.get(id, false): upgrade_button.text = "%s\nKURULU" % item.name; upgrade_button.disabled = true
    _build_goal_column()
    _build_sidebar()

func _build_goal_column() -> void:
    var panel := _panel(); panel.name = "goal_panel"; panel.custom_minimum_size.x = 300; panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL; stage.add_child(panel)
    var box := VBoxContainer.new(); box.add_theme_constant_override("separation", 12); panel.add_child(box)
    box.add_child(_section_label("BUGÜNÜN ODAĞI", YELLOW))
    var h := Label.new(); h.text = "Şehrin ritmini\nyakalamaya devam et."; h.add_theme_font_size_override("font_size", 27); h.add_theme_color_override("font_color", CREAM); box.add_child(h)
    var desc := Label.new(); desc.text = "Günün Oyunu'nda 3 eko zinciri kur. Kazandığın CC, ofisin bir sonraki adımı."; desc.add_theme_font_size_override("font_size", 16); desc.add_theme_color_override("font_color", MUTED); desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; box.add_child(desc)
    var reward_chip := Label.new(); reward_chip.text = "ÖDÜL  +15 CC  /  3 ZİNCİR"; reward_chip.add_theme_font_size_override("font_size", 13); reward_chip.add_theme_color_override("font_color", INK); reward_chip.add_theme_stylebox_override("normal", _style(YELLOW, 8)); box.add_child(reward_chip)
    goal_progress = ProgressBar.new(); goal_progress.max_value = 3; goal_progress.value = mini(GameState.score / 60.0, 3.0); goal_progress.custom_minimum_size.y = 14; goal_progress.show_percentage = false; goal_progress.add_theme_stylebox_override("background", _style(PANEL_2, 7)); goal_progress.add_theme_stylebox_override("fill", _style(YELLOW, 7)); box.add_child(goal_progress)
    goal_label = Label.new(); goal_label.add_theme_color_override("font_color", CREAM); box.add_child(goal_label)
    var play := _button("GÜNÜN OYUNUNA GİT  →", YELLOW, INK); play.custom_minimum_size.y = 58; play.pressed.connect(func(): _navigate("game")); box.add_child(play)
    var hint := Label.new(); hint.text = "İpucu  •  Bitişik taşları yatay veya dikey değiştir."; hint.add_theme_font_size_override("font_size", 14); hint.add_theme_color_override("font_color", MUTED); hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; box.add_child(hint)

func _build_sidebar() -> void:
    var panel := _panel(); panel.name = "sidebar_panel"; panel.custom_minimum_size.x = 300; panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL; stage.add_child(panel)
    var box := VBoxContainer.new(); box.add_theme_constant_override("separation", 10); panel.add_child(box)
    box.add_child(_section_label("YÖNETİM PANELİ", MUTED))
    var level := _metric("SEVİYE", "%d" % GameState.company_level, YELLOW); level.name = "metric_level"; box.add_child(level)
    var workers := _metric("ÇALIŞAN", "%d kişi" % GameState.employees, CREAM); workers.name = "metric_workers"; box.add_child(workers)
    var income := _metric("PASİF GELİR", "+%d CC / 15 sn" % GameState.passive_income, SAGE); income.name = "metric_income"; box.add_child(income)
    var climate := Label.new(); climate.name = "climate_metrics"; climate.text = "ENERJİ  %d / %d kWh\nSU TASARRUFU  %d L\nÖNLENEN EMİSYON  %d kg CO₂e\nATIK DÖNÜŞÜMÜ  %d kg" % [GameState.energy_produced, GameState.energy_used, GameState.water_saved, GameState.emissions_avoided, GameState.waste_diverted]; climate.add_theme_font_size_override("font_size", 14); climate.add_theme_color_override("font_color", SAGE); climate.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; box.add_child(climate)
    var climate_note := Label.new(); climate_note.text = "oyun içi yaklaşık değerler"; climate_note.add_theme_font_size_override("font_size", 11); climate_note.add_theme_color_override("font_color", MUTED); box.add_child(climate_note)
    var line := HSeparator.new(); line.modulate = Color(1,1,1,.14); box.add_child(line)
    var recruit := _button("EKİBİ BÜYÜT", SAGE, INK); recruit.custom_minimum_size.y = 48; recruit.pressed.connect(func(): _navigate("recruitment")); box.add_child(recruit)
    var upgrade := _button("OFİSİ GELİŞTİR", PANEL_2, CREAM); upgrade.custom_minimum_size.y = 48; upgrade.pressed.connect(func(): _navigate("office")); box.add_child(upgrade)
    var save := Label.new(); save.text = "Otomatik kayıt açık"; save.add_theme_font_size_override("font_size", 13); save.add_theme_color_override("font_color", MUTED); box.add_child(save)
    var impact := Label.new(); impact.text = "ŞEHİR ETKİSİ"; impact.add_theme_font_size_override("font_size", 12); impact.add_theme_color_override("font_color", MUTED); box.add_child(impact)
    var impact_bar := ProgressBar.new(); impact_bar.max_value = 5; impact_bar.value = GameState.company_level + GameState.employees - 1; impact_bar.show_percentage = false; impact_bar.custom_minimum_size.y = 12; impact_bar.add_theme_stylebox_override("background", _style(PANEL_2, 6)); impact_bar.add_theme_stylebox_override("fill", _style(SAGE, 6)); box.add_child(impact_bar)
    var impact_note := Label.new(); impact_note.text = "%d proje Antalya'da nefes alıyor" % (GameState.company_level + GameState.employees - 1); impact_note.add_theme_font_size_override("font_size", 13); impact_note.add_theme_color_override("font_color", SAGE); box.add_child(impact_note)

func _show_recruitment() -> void:
    _reset_stage(); title_label.text = "Yeni takım arkadaşları"
    var intro := _panel(); intro.custom_minimum_size.x = 270; intro.size_flags_horizontal = Control.SIZE_EXPAND_FILL; stage.add_child(intro)
    var ib := VBoxContainer.new(); ib.add_theme_constant_override("separation", 14); intro.add_child(ib); ib.add_child(_section_label("İŞE ALIM", YELLOW))
    var it := Label.new(); it.text = "Bu şehir tek başına\ndönüşmez."; it.add_theme_font_size_override("font_size", 30); it.add_theme_color_override("font_color", CREAM); ib.add_child(it)
    var idesc := Label.new(); idesc.text = "Her uzman farklı bir avantaj getirir. Ekibini CC ile büyüt."; idesc.add_theme_font_size_override("font_size", 16); idesc.add_theme_color_override("font_color", MUTED); idesc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; ib.add_child(idesc)
    for candidate in GameState.CANDIDATES: _add_candidate_card(candidate)
    var back := _button("← OFİSE DÖN", PANEL_2, CREAM); back.pressed.connect(func(): _navigate("office")); ib.add_child(back)

func _add_candidate_card(candidate: Dictionary) -> void:
    var card := _panel(); card.custom_minimum_size.x = 280; card.size_flags_horizontal = Control.SIZE_EXPAND_FILL; stage.add_child(card)
    var box := VBoxContainer.new(); box.add_theme_constant_override("separation", 8); card.add_child(box)
    box.add_child(_section_label("UZMAN", SAGE))
    var name := Label.new(); name.text = candidate.name; name.add_theme_font_size_override("font_size", 22); name.add_theme_color_override("font_color", CREAM); box.add_child(name)
    var role := Label.new(); role.text = candidate.role; role.add_theme_font_size_override("font_size", 15); role.add_theme_color_override("font_color", MUTED); role.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; box.add_child(role)
    var effect := Label.new(); effect.text = candidate.effect; effect.add_theme_font_size_override("font_size", 15); effect.add_theme_color_override("font_color", YELLOW); effect.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; effect.size_flags_vertical = Control.SIZE_EXPAND_FILL; box.add_child(effect)
    var b := _button("İŞE AL  •  %d CC" % candidate.cost, SAGE, INK); b.custom_minimum_size.y = 52; b.name = candidate.id; b.pressed.connect(func(): GameState.hire(candidate)); box.add_child(b)
    if GameState.hired.get(candidate.id, false): b.text = "EKİPTE"; b.disabled = true

func _show_game() -> void:
    _reset_stage(); title_label.text = "Günün Eko Oyunu"
    var info := _panel(); info.custom_minimum_size.x = 280; info.size_flags_horizontal = Control.SIZE_EXPAND_FILL; stage.add_child(info)
    var ib := VBoxContainer.new(); ib.add_theme_constant_override("separation", 12); info.add_child(ib); ib.add_child(_section_label("GÖREV BRİFİ", YELLOW))
    var h := Label.new(); h.text = "Temiz enerji\niçin eşleştir."; h.add_theme_font_size_override("font_size", 29); h.add_theme_color_override("font_color", CREAM); ib.add_child(h)
    var desc := Label.new(); desc.text = "Komşu iki taşı değiştir. Üç veya daha fazlasını bir araya getirince şirketin için CC kazan."; desc.add_theme_font_size_override("font_size", 16); desc.add_theme_color_override("font_color", MUTED); desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; ib.add_child(desc)
    var rule := Label.new(); rule.text = "Güneş  •  Rüzgâr  •  Su\nFidan  •  Geri dönüşüm"; rule.add_theme_font_size_override("font_size", 15); rule.add_theme_color_override("font_color", SAGE); ib.add_child(rule)
    var reset := _button("↻ YENİLE", PANEL_2, CREAM); reset.pressed.connect(func(): board.reset_game()); ib.add_child(reset)
    var board_panel := _panel(); board_panel.custom_minimum_size.x = 470; board_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL; stage.add_child(board_panel)
    board = preload("res://scripts/match3_board.gd").new(); board.set_anchors_and_offsets_preset(Control.PRESET_CENTER); board.custom_minimum_size = Vector2(420, 420); board.reward.connect(_on_reward); board_panel.add_child(board)
    var score_panel := _panel(); score_panel.name = "score_panel"; score_panel.custom_minimum_size.x = 270; score_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL; stage.add_child(score_panel)
    var sb := VBoxContainer.new(); sb.add_theme_constant_override("separation", 10); score_panel.add_child(sb); sb.add_child(_section_label("OTURUM", MUTED))
    var score := _metric("SKOR", "%05d" % GameState.score, YELLOW); score.name = "game_score"; sb.add_child(score)
    var moves := _metric("HAMLE", "18 / 18", CREAM); moves.name = "game_moves"; sb.add_child(moves)
    var reward := Label.new(); reward.text = "Her eşleşme şirket kasasına\n3+ CC ekler."; reward.add_theme_font_size_override("font_size", 16); reward.add_theme_color_override("font_color", MUTED); reward.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; sb.add_child(reward)
    var back := _button("← OFİSE DÖN", PANEL_2, CREAM); back.pressed.connect(func(): _navigate("office")); sb.add_child(back)

func _on_reward(points: int, chains: int) -> void:
    GameState.add_match_reward(points, chains); GameState.save_progress(); _refresh()

func _refresh() -> void:
    if cc_label: cc_label.text = "%d CC" % GameState.carbon_credits
    if goal_progress:
        goal_progress.value = mini(GameState.score / 60.0, 3.0); goal_label.text = "%d / 3 eko zinciri" % int(goal_progress.value)
    if stage:
        for target in ["office", "recruitment", "game"]:
            var nav := get_node_or_null("VBoxContainer/nav_" + target)
            if nav: nav.modulate = Color(1,1,1,1) if page == target else Color(.65,.75,.7,1)
        if page == "office":
            var l := stage.get_node_or_null("sidebar_panel/VBoxContainer/metric_level/value"); if l: l.text = "%d" % GameState.company_level
            var w := stage.get_node_or_null("sidebar_panel/VBoxContainer/metric_workers/value"); if w: w.text = "%d kişi" % GameState.employees
            var inc := stage.get_node_or_null("sidebar_panel/VBoxContainer/metric_income/value"); if inc: inc.text = "+%d CC / 15 sn" % GameState.passive_income
            var climate := stage.get_node_or_null("sidebar_panel/VBoxContainer/climate_metrics"); if climate: climate.text = "ENERJİ  %d / %d kWh\nSU TASARRUFU  %d L\nÖNLENEN EMİSYON  %d kg CO₂e\nATIK DÖNÜŞÜMÜ  %d kg" % [GameState.energy_produced, GameState.energy_used, GameState.water_saved, GameState.emissions_avoided, GameState.waste_diverted]
            for id in GameState.UPGRADES.keys():
                var up := stage.get_node_or_null("office_panel/VBoxContainer/upgrade_flow/upgrade_" + id)
                if up and GameState.upgrades.get(id, false): up.text = "%s\nKURULU" % GameState.UPGRADES[id].name; up.disabled = true
        if page == "game":
            var s := stage.get_node_or_null("score_panel/VBoxContainer/game_score/value"); if s: s.text = "%05d" % GameState.score
            var m := stage.get_node_or_null("score_panel/VBoxContainer/game_moves/value"); if m and board: m.text = "%d / 18" % board.moves

func _show_toast(message: String) -> void:
    if toast: toast.text = message
    GameState.save_progress()
    if office: office.queue_redraw()

func _panel() -> PanelContainer:
    var p := PanelContainer.new(); p.add_theme_stylebox_override("panel", _style(PANEL, 22)); p.add_theme_constant_override("margin_left", 22); p.add_theme_constant_override("margin_right", 22); p.add_theme_constant_override("margin_top", 20); p.add_theme_constant_override("margin_bottom", 20); return p

func _metric(label: String, value: String, color: Color) -> VBoxContainer:
    var box := VBoxContainer.new(); box.add_theme_constant_override("separation", 1); var caption := Label.new(); caption.text = label; caption.add_theme_font_size_override("font_size", 12); caption.add_theme_color_override("font_color", MUTED); box.add_child(caption); var val := Label.new(); val.name = "value"; val.text = value; val.add_theme_font_size_override("font_size", 24); val.add_theme_color_override("font_color", color); box.add_child(val); return box

func _section_label(text: String, color: Color) -> Label:
    var label := Label.new(); label.text = text; label.add_theme_font_size_override("font_size", 13); label.add_theme_color_override("font_color", color); return label

func _button(text: String, color: Color, ink: Color) -> Button:
    var b := Button.new(); b.text = text; b.add_theme_font_size_override("font_size", 15); b.add_theme_color_override("font_color", ink); b.add_theme_stylebox_override("normal", _style(color, 12)); b.add_theme_stylebox_override("hover", _style(YELLOW if color != YELLOW else SAGE, 12)); b.add_theme_stylebox_override("pressed", _style(SAGE, 12)); return b

func _style(color: Color, radius: int) -> StyleBoxFlat:
    var s := StyleBoxFlat.new(); s.bg_color = color; s.corner_radius_top_left = radius; s.corner_radius_top_right = radius; s.corner_radius_bottom_left = radius; s.corner_radius_bottom_right = radius; return s
