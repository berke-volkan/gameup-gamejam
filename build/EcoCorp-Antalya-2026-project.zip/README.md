# EcoCorp: Antalya 2026

Godot 4.x ile hazırlanmış, yatay ekranlı Türkçe hackathon prototipi.

## Çalıştırma

Godot 4.x'i açın, `project.godot` dosyasını import edin ve **Play Project** ile çalıştırın. Proje tam ekran yatay ana menüyle açılır. `Oyuna Başla` ile yönetim paneline geçilir. Editörde fare, Android'de dokunma kullanılabilir.

Android denemesi için Godot Android export şablonlarını kurup Project > Export > Android üzerinden APK/AAB alın. USB hata ayıklama açık bir Android cihaz veya Android emülatörü seçin.

Bu projede Android preset'i `export_presets.cfg` içinde hazırdır. Export Templates ve Java SDK kurulduktan sonra komut satırından `godot --path . --export-release "Android" build/EcoCorp-Antalya-2026.apk` kullanılabilir.

## Demo akışı

150 CC ile başlayın; Günün Oyunu ekranında 3+ taş eşleştirip CC kazanın. Ofisten yükseltme, İşe Alım'dan uzman satın alın. 15 saniyede bir pasif gelir hesabınıza eklenir. İlerleme `user://ecocorp_save.json` altında tutulur.

## Bilinen eksikler

- Hareket animasyonları yerine hızlı ve okunaklı çözüm kullanıldı.
- Gerçek cihaz testi bu teslimatta yapılmadı.
- Ses, titreşim ve daha zengin sanat varlıkları sonraki iterasyona bırakıldı.
